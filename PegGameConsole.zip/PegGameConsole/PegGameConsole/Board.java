import java.util.*;

public class Board
{
    private String[] arr;
    
    public Board(String[] arr)
    {
        this.arr = arr;
    }
    
    /**
     * Prints the board
     */
    public void printBoard()
    {
        System.out.println("      " + arr[0]);
        System.out.println("     " + arr[1] + " " + arr[2]);
        System.out.println("    " + arr[3] + " " + arr[4] + " " + arr[5]);
        System.out.println("   " + arr[6] + " " + arr[7] + " " + arr[8] + " " + arr[9]);
        System.out.println("  " + arr[10] + " " + arr[11] + " " + arr[12] + " " + arr[13] + " " + arr[14]);
    }
    
    public boolean isValid(String from, String to)
    {
        int fromInt = -1;
        int toInt = -1;
        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i].equals(from)) { fromInt = i;}
            if(arr[i].equals(to)) { toInt = i;}
        }
        
        if((from.equals("D") && to.equals("a") && arr[1].equals("B")) || (from.equals("F") && to.equals("a") && arr[2].equals("C")))
        {
            return true;
        }
        if((from.equals("G") && to.equals("b") && arr[3].equals("D")) || (from.equals("I") && to.equals("b") && arr[4].equals("E")))
        {
            return true;
        }
        if((from.equals("H") && to.equals("c") && arr[4].equals("E")) || (from.equals("J") && to.equals("c") && arr[5].equals("F")))
        {
            return true;
        }
        if((from.equals("A") && to.equals("d") && arr[1].equals("B")) || (from.equals("K") && to.equals("d") && arr[6].equals("G")) || (from.equals("F") && to.equals("d") && arr[4].equals("E")) || (from.equals("M") && to.equals("d") && arr[7].equals("H")))
        {
            return true;
        }
        if((from.equals("L") && to.equals("e") && arr[7].equals("H")) || (from.equals("N") && to.equals("e") && arr[8].equals("I")))
        {
            return true;
        }
        if((from.equals("A") && to.equals("f") && arr[2].equals("C")) || (from.equals("O") && to.equals("f") && arr[9].equals("J")) || (from.equals("D") && to.equals("f") && arr[4].equals("E")) || (from.equals("M") && to.equals("f") && arr[8].equals("I")))
        {
            return true;
        }
        if((from.equals("B") && to.equals("g") && arr[3].equals("D")) || (from.equals("I") && to.equals("g") && arr[7].equals("H")))
        {
            return true;
        }
        if((from.equals("C") && to.equals("h") && arr[4].equals("E")) || (from.equals("J") && to.equals("h") && arr[8].equals("I")))
        {
            return true;
        }
        if((from.equals("B") && to.equals("i") && arr[4].equals("E")) || (from.equals("G") && to.equals("i") && arr[7].equals("H")))
        {
            return true;
        }
        if((from.equals("C") && to.equals("j") && arr[5].equals("F")) || (from.equals("H") && to.equals("j") && arr[8].equals("I")))
        {
            return true;
        }
        if((from.equals("D") && to.equals("k") && arr[6].equals("G")) || (from.equals("M") && to.equals("k") && arr[11].equals("L")))
        {
            return true;
        }
        if((from.equals("E") && to.equals("l") && arr[7].equals("H")) || (from.equals("N") && to.equals("l") && arr[12].equals("M")))
        {
            return true;
        }
        if((from.equals("D") && to.equals("m") && arr[7].equals("H")) || (from.equals("F") && to.equals("m") && arr[8].equals("I")) || (from.equals("K") && to.equals("m") && arr[11].equals("L")) || (from.equals("O") && to.equals("m") && arr[13].equals("N")))
        {
            return true;
        }
        if((from.equals("E") && to.equals("n") && arr[8].equals("I")) || (from.equals("L") && to.equals("n") && arr[12].equals("M")))
        {
            return true;
        }
        if((from.equals("F") && to.equals("o") && arr[9].equals("J")) || (from.equals("M") && to.equals("o") && arr[13].equals("N")))
        {
            return true;
        }
        return false;
    }
    
    public void move(String from, String to)
    {
        int fromInt = -1;
        int toInt = -1;
        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i].equals(from)) { fromInt = i;}
            if(arr[i].equals(to)) { toInt = i;}
        }
        if(isValid(from, to))
        {
            arr[toInt] = (char) ('A' + toInt) + "";
            arr[fromInt] = (char) ('a' + fromInt) + "";
            
            if((from.equals("D") && to.equals("a")) || (from.equals("F") && to.equals("a")))
            {
                if(from.equals("D")) { arr[1] = arr[1].toLowerCase();}
                if(from.equals("F")) { arr[2] = arr[2].toLowerCase();}
            }
            if((from.equals("G") && to.equals("b")) || (from.equals("I") && to.equals("b")))
            {
                if(from.equals("G")) { arr[3] = arr[3].toLowerCase();}
                if(from.equals("I")) { arr[4] = arr[4].toLowerCase();}
            }
            if((from.equals("H") && to.equals("c")) || (from.equals("J") && to.equals("c")))
            {
                if(from.equals("H")) { arr[4] = arr[4].toLowerCase();}
                if(from.equals("J")) { arr[5] = arr[5].toLowerCase();}
            }
            if((from.equals("A") && to.equals("d")) || (from.equals("K") && to.equals("d")) || (from.equals("F") && to.equals("d")) || (from.equals("M") && to.equals("d")))
            {
                if(from.equals("A")) { arr[1] = arr[1].toLowerCase();}
                if(from.equals("K")) { arr[6] = arr[6].toLowerCase();}
                if(from.equals("F")) { arr[4] = arr[4].toLowerCase();}
                if(from.equals("M")) { arr[7] = arr[7].toLowerCase();}
            }
            if((from.equals("L") && to.equals("e")) || (from.equals("N") && to.equals("e")))
            {
                if(from.equals("L")) { arr[7] = arr[7].toLowerCase();}
                if(from.equals("N")) { arr[8] = arr[8].toLowerCase();}
            }
            if((from.equals("A") && to.equals("f")) || (from.equals("O") && to.equals("f")) || (from.equals("D") && to.equals("f")) || (from.equals("M") && to.equals("f")))
            {
                if(from.equals("A")) { arr[2] = arr[2].toLowerCase();}
                if(from.equals("O")) { arr[9] = arr[9].toLowerCase();}
                if(from.equals("D")) { arr[4] = arr[4].toLowerCase();}
                if(from.equals("M")) { arr[8] = arr[8].toLowerCase();}
            }
            if((from.equals("B") && to.equals("g")) || (from.equals("I") && to.equals("g")))
            {
                if(from.equals("B")) { arr[3] = arr[3].toLowerCase();}
                if(from.equals("I")) { arr[7] = arr[7].toLowerCase();}
            }
            if((from.equals("C") && to.equals("h")) || (from.equals("J") && to.equals("h")))
            {
                if(from.equals("C")) { arr[4] = arr[4].toLowerCase();}
                if(from.equals("J")) { arr[8] = arr[8].toLowerCase();}
            }
            if((from.equals("B") && to.equals("i")) || (from.equals("G") && to.equals("i")))
            {
                if(from.equals("B")) { arr[4] = arr[4].toLowerCase();}
                if(from.equals("G")) { arr[7] = arr[7].toLowerCase();}
            }
            if((from.equals("C") && to.equals("j")) || (from.equals("H") && to.equals("j")))
            {
                if(from.equals("C")) { arr[5] = arr[5].toLowerCase();}
                if(from.equals("H")) { arr[8] = arr[8].toLowerCase();}
            }
            if((from.equals("D") && to.equals("k")) || (from.equals("M") && to.equals("k")))
            {
                if(from.equals("D")) { arr[6] = arr[6].toLowerCase();}
                if(from.equals("M")) { arr[11] = arr[11].toLowerCase();}
            }
            if((from.equals("E") && to.equals("l")) || (from.equals("N") && to.equals("l")))
            {
                if(from.equals("E")) { arr[7] = arr[7].toLowerCase();}
                if(from.equals("N")) { arr[12] = arr[12].toLowerCase();}
            }
            if((from.equals("D") && to.equals("m")) || (from.equals("F") && to.equals("m")) || (from.equals("K") && to.equals("m")) || (from.equals("O") && to.equals("m")))
            {
                if(from.equals("D")) { arr[7] = arr[7].toLowerCase();}
                if(from.equals("F")) { arr[8] = arr[8].toLowerCase();}
                if(from.equals("K")) { arr[11] = arr[11].toLowerCase();}
                if(from.equals("O")) { arr[13] = arr[13].toLowerCase();}
            }
            if((from.equals("E") && to.equals("n")) || (from.equals("L") && to.equals("n")))
            {
                if(from.equals("E")) { arr[8] = arr[8].toLowerCase();}
                if(from.equals("L")) { arr[12] = arr[12].toLowerCase();}
            }
            if((from.equals("F") && to.equals("o")) || (from.equals("M") && to.equals("o")))
            {
                if(from.equals("F")) { arr[9] = arr[9].toLowerCase();}
                if(from.equals("M")) { arr[13] = arr[13].toLowerCase();}
            }
        }
    }
    
    public boolean checkWin()
    {
        int c = 0;
        for(int i = 0; i < arr.length; i++)
        {
            if(arr[i].equals((char) ('A' + i) + "")) { c++;}
        }
        if(c == 1) {return true;}
        return false;
    }
    
    public int possibleSolutions()
    {
        int num = 0;
        for(int i = 0; i < arr.length; i++)
        {
            for(int j = 0; j < arr.length; j++)
            {
                if(isValid(arr[i], arr[j]))
                {
                    num++;
                }
            }
        }
        return num;
    }
}