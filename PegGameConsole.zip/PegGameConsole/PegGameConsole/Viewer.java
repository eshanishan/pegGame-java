import java.util.*;

public class Viewer
{
    public static void main(String[] args)
    {
        String[] arr = {"a", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O"};
        Board board = new Board(arr);
        while(!board.checkWin() && board.possibleSolutions() > 0)
        {
            board.printBoard();
            Scanner in = new Scanner(System.in);
            System.out.println("First Button: ");
            String from = in.nextLine();
            System.out.println("Second Button: ");
            String to = in.nextLine();
            board.move(from, to);
        }
        if(board.checkWin()) {System.out.println("Let's Go!!!! You win!!!!");}
        else {System.out.println("Unlucky:( You lost!");}
    }
}